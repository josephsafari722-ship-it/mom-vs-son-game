Mom vs Son — Dungeon Chappal Chase

PLAY LOCALLY
1. Extract this ZIP.
2. Open index.html in a modern browser (Chrome, Edge, or Firefox).
3. Press Enter at the title screen.

IMPORTANT FOR POKI
This is a standalone HTML5/Canvas build. A ZIP alone is not a public playable URL. To submit it to a portal that asks for a playable URL, host the game online first and test the hosted version. Poki may require technical review and SDK integration before publication; follow the current Poki developer guide.

CONTROLS
Mom: WASD to move; Q to jump; hold C to aim/charge; use V to adjust aim; Tab to throw.
Son: Arrow keys to move; Right Shift to jump; / to boost.
Enter: start/restart; Esc: return to menu.
